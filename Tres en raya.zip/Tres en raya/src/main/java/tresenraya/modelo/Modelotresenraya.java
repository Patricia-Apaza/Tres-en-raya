/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tresenraya.modelo;
import lombok.Data;
        
/**
 *
 * @author HP
 */
@Data
public class Modelotresenraya {
    public String nombre_partida,nombre_jugador1,nombre_jugador2,ganador,estado;
    public int punto, idresultado;
    
}
