package tresenraya.gui;

import java.awt.*;
import javax.swing.*;
import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class Juego3 {

    private int Turno;
    private int pX, pO; 
    private char token = 'x'; 

    public Juego3() {
        this.Turno = 0; 
        this.pX = 0; 
        this.pO = 0; 
    }


    public int getTurno() {
        return this.Turno;
    }

    
    public void cambioTurno() {
        if (this.Turno == 0) {
            this.Turno = 1;
            this.token = 'o';
        } else {
            this.Turno = 0;
            this.token = 'x';
        }
    }

    
    public boolean comprobarJuego(char[][] tablero) {
        boolean Ganador = false;
        if ( // Fila 1
                tablero[0][0] == token
                && tablero[0][1] == token
                && tablero[0][2] == token
                // Fila 2
                || tablero[1][0] == token
                && tablero[1][1] == token
                && tablero[1][2] == token
                // Fila 3
                || tablero[2][0] == token
                && tablero[2][1] == token
                && tablero[2][2] == token
                // Columna 1
                || tablero[0][0] == token
                && tablero[1][0] == token
                && tablero[2][0] == token
                // Columna 2
                || tablero[0][1] == token
                && tablero[1][1] == token
                && tablero[2][1] == token
                // Columna 3
                || tablero[0][2] == token
                && tablero[1][2] == token
                && tablero[2][2] == token
                // Diagona 1
                || tablero[0][0] == token
                && tablero[1][1] == token
                && tablero[2][2] == token
                // Diagona 2
                || tablero[0][2] == token
                && tablero[1][1] == token
                && tablero[2][0] == token) {
            Ganador = true;
        }
        return Ganador;
    }

  
    public void pintarFicha(JButton Boton) {
        if (this.Turno == 0) {
            Boton.setForeground(Color.red);
        } else {
            Boton.setForeground(Color.blue);
        }
    }

    
    public void ponerFicha(JButton Boton, int x, int y, char[][] tablero) {
        pintarFicha(Boton);
        Boton.setText(this.token + "");
        tablero[x][y] = this.token;
    }

    
    public void tiradaJugador(JButton Boton, int x, int y, char[][] tablero, JLabel labelx, JLabel labelo, JPanel panel) {
        ponerFicha(Boton, x, y, tablero);
        Boton.setEnabled(false);
        if (comprobarJuego(tablero)) {
            habilitarTrablero(panel, false);
            ganador(labelx, labelo);
        }
        cambioTurno();
    }

    
    public void ganador(JLabel labelx, JLabel labelo) {
        if (this.Turno == 0) { // En este caso : es Turno de X
            pX += 1;
        } else { // En este caso : es Turno de O
            pO += 1;
        }
        labelx.setText(pX + "");
        labelo.setText(pO + "");
    }

    
    public void habilitarTrablero(JPanel panel, boolean habilitado) {
        for (Component Boton : panel.getComponents()) {
            if (Boton instanceof JButton) {
                Boton.setEnabled(habilitado);
                // Si se habilitan se restablecerá el texto
                if (habilitado) {
                    ((JButton) Boton).setText("  ");
                }
            }
        }
    }

    public void deshabilitarTrablero(JPanel panel, boolean deshabilitado) {
        for (Component Boton : panel.getComponents()) {
            if (Boton instanceof JButton) {
                Boton.setEnabled(deshabilitado);
                // Si se habilitan se restablecerá el texto
                if (deshabilitado) {
                    ((JButton) Boton).setText("  ");
                }
            }
        }
    }
        
    public void iniciarPartida(JPanel panel, boolean habilitado, char[][] tablero) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                tablero[i][j] = ' ';
            }
        }
        habilitarTrablero(panel, habilitado);
    }
    public void teminarPartida(JPanel panel, boolean deshabilitado, char[][] tablero) {
        for (int i = 1; i < 0; i++) {
            for (int j = 1; j < 0; j++) {
                tablero[i][j] = ' ';
            }
        }
        deshabilitarTrablero(panel, deshabilitado);
    }

}
